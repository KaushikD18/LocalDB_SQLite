//
//  screen2.swift
//  LocalDB_Demo
//
//  Created by Kaushik Darji on 25/08/23.
//

import UIKit

class screen2: UIViewController {

    // MARK: - Refference Outlet and Variables

    @IBOutlet weak var collectionviewButtons: UICollectionView!
    var value = ""
    var backToView:((_ isCancel: Bool, _ tappedButton : String) -> Void)!

    // MARK: - viewDidLoad

    override func viewDidLoad() {
        super.viewDidLoad()
    }
}

// MARK: - Collectionview Delegate & DataSource Method's

extension screen2: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return Int(value) ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = self.collectionviewButtons.dequeueReusableCell(withReuseIdentifier: "buttonsCell", for: indexPath) as! buttonsCell
        cell.buttons.setTitle("Button \(indexPath.row + 1)", for: .normal)
        cell.buttons.layer.cornerRadius = 5
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 150, height: 60)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        backToView(true, "\(indexPath.row + 1)")
        self.navigationController?.popViewController(animated: true)
    }
}

// MARK: - CollectionView Cell

class buttonsCell: UICollectionViewCell {
    @IBOutlet weak var buttons: UIButton!
}
