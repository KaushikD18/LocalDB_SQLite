//
//  screen1.swift
//  LocalDB_Demo
//
//  Created by Kaushik Darji on 24/08/23.
//

import UIKit
import KRProgressHUD
import SDWebImage
import SQLite


class screen1: UIViewController {

    // MARK: - Refference Outlet and Variables

    @IBOutlet weak var lblSelectedBtton: UILabel!
    @IBOutlet weak var txt_NumberButtons: UITextField!
    @IBOutlet weak var btnNext: UIButton!
    @IBOutlet weak var collectionviewImages: UICollectionView!
    @IBOutlet weak var txtNumber: UITextField!
    @IBOutlet weak var btnSubmit: UIButton!
    
    var db = DBManager()

    // MARK: - viewDidLoad

    override func viewDidLoad() {
        super.viewDidLoad()
        self.initialSetup()
    }
}

// MARK: - Function's

extension screen1 {
    func initialSetup(){
        self.btnSubmit.layer.cornerRadius = 5
        self.btnNext.layer.cornerRadius = 5
        DispatchQueue.main.async {
            if let appDelegate = UIApplication.shared.delegate as? AppDelegate {
                if appDelegate.isConnectedToNetwork == false {
                    _ = self.db.read()
                    self.collectionviewImages.reloadData()
                }
            }
        }
    }
}

// MARK: - IBActions's

extension screen1 {
    @IBAction func btnSubmitAction(_ sender: Any) {
        let appDelegate = UIApplication.shared.delegate as? AppDelegate
        if appDelegate?.isConnectedToNetwork == true {
            self.db.deleteData() // if you wanna remove table data when user tapped on submit button for new API call then need to execute this code otherwise no.
            self.API_fetchImage2()
        }else{
            AlertMessage.showError(message: "Please check your internet connection.")
        }
    }
    
    @IBAction func btnNext(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "screen2") as! screen2
        vc.value = self.txt_NumberButtons.text ?? ""
        vc.backToView = { [weak self] (isCancel, tappedButton) in
            if isCancel {
                self?.lblSelectedBtton.isHidden = false
                self?.lblSelectedBtton.text = "You have clicked button \(tappedButton)"
                print("tapped button:",tappedButton)
            }
        }
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

// MARK: - Collectionview Delegate & DataSource Method's

extension screen1: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return screen1ViewModel.instance.imageList.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = self.collectionviewImages.dequeueReusableCell(withReuseIdentifier: "imageCell", for: indexPath) as! imageCell
        cell.imageBanner.layer.cornerRadius = 5.0
        cell.imageBanner.sd_setImage(with: URL(string: screen1ViewModel.instance.imageList[indexPath.row].image_url), placeholderImage: UIImage())
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 150, height: 150)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
    }
}

// MARK: - API

extension screen1 {
    func API_fetchImage2()
    {
        screen1ViewModel.instance.API_fetchData(value: self.txtNumber.text ?? "") { response in
            print("response fetched successfully.")
            self.collectionviewImages.reloadData()
        } failure: { error in
            self.collectionviewImages.reloadData()
        }
    }
}

// MARK: - CollectionView Cell

class imageCell: UICollectionViewCell {
    @IBOutlet weak var imageBanner: UIImageView!
}
