//
//  DBManager.swift
//  LocalDB_Demo
//
//  Created by Kaushik Darji on 24/08/23.
//

import Foundation
import SQLite3
import ObjectMapper
  
class DBManager
{
    init()
    {
        db = openDatabase()
        createTable()
    }
    
    let dbPath: String = "myDb.sqlite"
    var db:OpaquePointer?
    
    
    func openDatabase() -> OpaquePointer?
    {
        let filePath = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
            .appendingPathComponent(dbPath)
        var db: OpaquePointer? = nil
        if sqlite3_open(filePath.path, &db) != SQLITE_OK{
            debugPrint("can't open database")
            return nil
        }else{
            print(filePath.path)
            print("Successfully created connection to database at \(dbPath)")
            return db
        }
    }
    
    func createTable() {
        let createTableString = "CREATE TABLE IF NOT EXISTS images(Id INTEGER PRIMARY KEY,image TEXT);"
        var createTableStatement: OpaquePointer? = nil
        if sqlite3_prepare_v2(db, createTableString, -1, &createTableStatement, nil) == SQLITE_OK {
            if sqlite3_step(createTableStatement) == SQLITE_DONE{
                print("image table created.")
            }else {
                print("image table could not be created.")
            }
        }else {
            print("CREATE TABLE statement could not be prepared.")
        }
        sqlite3_finalize(createTableStatement)
    }
    
    func insert(image:String)
    {
        let insertStatementString = "INSERT INTO images (image) VALUES (?);"
        var insertStatement: OpaquePointer? = nil
        if sqlite3_prepare_v2(db, insertStatementString, -1, &insertStatement, nil) == SQLITE_OK {
            sqlite3_bind_text(insertStatement, 1, (image as NSString).utf8String, -1, nil)
              
            if sqlite3_step(insertStatement) == SQLITE_DONE {
                print("Successfully inserted row.")
            } else {
                print("Could not insert row.")
            }
        } else {
            print("INSERT statement could not be prepared.")
        }
        sqlite3_finalize(insertStatement)
    }

    
    func read() -> [imageModel] {
        let queryStatementString = "SELECT * FROM images;"
        var queryStatement: OpaquePointer? = nil
        var emps : [imageModel] = []
        if sqlite3_prepare_v2(db, queryStatementString, -1, &queryStatement, nil) == SQLITE_OK {
            while sqlite3_step(queryStatement) == SQLITE_ROW {
                let image = String(describing: String(cString: sqlite3_column_text(queryStatement, 1)))
                var dictdata = [String:Any]()
                dictdata["image_url"] = image
                var imgData = imageModel()
                imgData =  Mapper<imageModel>().map(JSONObject: dictdata)!
                emps.append(imgData)
            }
        } else {
            print("SELECT statement could not be prepared")
        }
        sqlite3_finalize(queryStatement)
        screen1ViewModel.instance.imageList = emps
        return emps
    }
    
    func deleteData() {
        let tableName = "images"
        let deleteStatementString = "DELETE FROM \(tableName);"
        var deleteStatement: OpaquePointer? = nil
        if sqlite3_prepare_v2(db, deleteStatementString, -1, &deleteStatement, nil) == SQLITE_OK {
            if sqlite3_step(deleteStatement) == SQLITE_DONE {
                print("Successfully deleted all rowns from \(tableName)")
            } else {
                print("Could not delete all rowns from \(tableName)")
            }
        } else {
            print("DELETE statement could not be prepared")
        }
        sqlite3_finalize(deleteStatement)
    }
}
