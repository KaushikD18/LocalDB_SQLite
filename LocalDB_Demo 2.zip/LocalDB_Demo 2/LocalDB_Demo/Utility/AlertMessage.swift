import Foundation
import SwiftMessages

class AlertMessage {
    static func showError(message: String) {
        let view = MessageView.viewFromNib(layout: .messageView)
        view.configureContent(title: nil, body: message, iconImage: nil, iconText: nil, buttonImage: nil, buttonTitle: nil, buttonTapHandler: nil)
        view.configureTheme(.warning, iconStyle: .none)
        view.accessibilityPrefix = "error"
        view.configureDropShadow()
        view.backgroundView.backgroundColor = UIColor .black
        view.button?.isHidden = true
        var config = SwiftMessages.defaultConfig
        config.duration = .seconds(seconds: 3.0)
        config.presentationStyle = .top
        config.presentationContext = .window(windowLevel: UIWindow.Level.alert)
        config.preferredStatusBarStyle = .darkContent
        SwiftMessages.show(config: config, view: view)
    }
    
    static func showSuccess(message: String) {
        let view = MessageView.viewFromNib(layout: .messageView)
        view.configureContent(title: nil, body: message, iconImage: nil, iconText: nil, buttonImage: nil, buttonTitle: nil, buttonTapHandler: nil)
        view.configureTheme(.success, iconStyle: .none)
        view.accessibilityPrefix = "success"
        view.backgroundView.backgroundColor = UIColor.black
        view.configureDropShadow()
        view.button?.isHidden = true
        var config = SwiftMessages.defaultConfig
        config.duration = .seconds(seconds: 3.0)
        config.presentationStyle = .top
        config.presentationContext = .window(windowLevel: UIWindow.Level.alert)
        config.preferredStatusBarStyle = .darkContent
        SwiftMessages.show(config: config, view: view)
    }
}

extension UIViewController {
    
    func confirmAlert(title: String, message: String, yesActionTitle: String = "Yes", noActionTitle: String = "No", confirmAction: @escaping () -> Void) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: yesActionTitle, style: .default, handler: { (action) in
            confirmAction()
        }))
        alert.addAction(UIAlertAction(title: noActionTitle, style: .default, handler: { (action) in
        }))
        self.present(alert, animated: true, completion: nil)
    }
    
    func showAlertView(View:UIViewController, message : String)
    {
        let alert = UIAlertController(title: NSLocalizedString("LocalDB_Demo", comment: ""), message: NSLocalizedString(message, comment: ""), preferredStyle: .alert)
        let okAction = UIAlertAction(title: NSLocalizedString("OK", comment: ""), style: .default, handler: nil)
        alert.addAction(okAction)
        DispatchQueue.main.async {
            View.present(alert, animated: true, completion: nil)
        }
    }
}
