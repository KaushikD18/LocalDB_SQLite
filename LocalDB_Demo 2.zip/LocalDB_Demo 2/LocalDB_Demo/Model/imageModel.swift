//
//  imageModel.swift
//  LocalDB_Demo
//
//  Created by Kaushik Darji on 24/08/23.
//

import Foundation
import ObjectMapper

class imageModel:NSObject, Mappable
{
    var image_url = ""

    override init() {
    }
    
    required init?(map: Map){
    
    }
    
    func mapping(map: Map) {
        image_url <- map["image_url"]
    }
}
