//
//  screen1ViewModel.swift
//  LocalDB_Demo
//
//  Created by Kaushik Darji on 24/08/23.
//

import Foundation
import ObjectMapper
import SwiftyJSON
import KRProgressHUD

class screen1ViewModel {
    static var instance: screen1ViewModel = screen1ViewModel()
    var imageList = [imageModel]()
    var db = DBManager()

    // MARK: - API's

    func API_fetchData(value: String, sucess success: @escaping (_ response: JSON) -> Void, failure: @escaping (_ error: Error?) -> Void) {
        guard let url = URL(string: "") else {
            return
        }
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        KRProgressHUD.show()
        let task = URLSession.shared.dataTask(with: request as URLRequest) { data, response, error in
            OperationQueue.main.addOperation {
                if response != nil {
                    KRProgressHUD.dismiss()
                    do {
                        if let responseJSON = try JSONSerialization.jsonObject(with: data!) as? [String:AnyObject]
                        {
                            let result  = JSON(data!)
                            if let bodyData = result["data"].rawValue as? [[String : Any]]{
                                self.imageList = Mapper<imageModel>().mapArray(JSONArray:bodyData)
                                self.saveDataLocal()
                            }
                            success(result)
                        }else{
                            let requestReply1 = String(data: data!, encoding: .ascii)
                            failure(error)
                        }
                    } catch let error as NSError {
                        let requestReply1 = String(data: data!, encoding: .ascii)
                        print(error.localizedDescription)
                    }
                } else {
                    failure(error)
                    KRProgressHUD .dismiss()
                }
            }
        }.resume()
    }
    
    // MARK: - Save API Data TO Local DB And Load the Data When Connection Is Lost.

    func saveDataLocal()
    {
        for data in self.imageList {
            self.db.insert(image: "\(data.image_url)")
        }
    }
}
